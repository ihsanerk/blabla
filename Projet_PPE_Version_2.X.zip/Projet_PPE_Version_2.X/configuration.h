#ifndef CONFIGURATION_H
#define	CONFIGURATION_H








//Prototypes
void pinConfiguration ();


#endif	/* CONFIGURATION_H */

