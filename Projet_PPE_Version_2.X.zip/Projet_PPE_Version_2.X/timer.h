#ifndef TIMER_H
#define	TIMER_H

#include <stdio.h>
#include <stdlib.h>
#include <p33EP512MU810.h>
#include <libpic30.h>
#include <pps.h>

void timerInit();
void jackInit ();

#endif	/* TIMER_H */

