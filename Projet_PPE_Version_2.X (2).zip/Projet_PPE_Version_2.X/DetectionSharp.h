#ifndef DETECTIONSHARP_H
#define	DETECTIONSHARP_H

//Librairies
#include "math.h"
#include "debugger.h"

//Constante
#define NB_SHARP 2
#define NB_SAMPLE 6

//Prototypes
void detectionSharpInit ();
void adc_detection();


#endif	/* DETECTIONSHARP_H */

